﻿using UnityEngine;

namespace td.monoBehaviours
{
#if UNITY_EDITOR
    [SelectionBase]
    public class SelectionBase : MonoBehaviour
    {
        
    }
#endif
}