﻿using System;

namespace td.features.impactsKernel
{
    [Serializable]
    public struct KernalDamageOuterCommand
    {
        public float damage;
    }
}