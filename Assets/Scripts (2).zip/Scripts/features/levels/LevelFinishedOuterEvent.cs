﻿using System;

namespace td.features.levels
{
    [Serializable]
    public struct LevelFinishedOuterEvent
    {
        
    }
}