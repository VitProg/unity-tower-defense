﻿using System;

namespace td.features.waves
{
    [Serializable]
    public struct AllEnemiesAreOverOuterWait
    {
        
    }
}