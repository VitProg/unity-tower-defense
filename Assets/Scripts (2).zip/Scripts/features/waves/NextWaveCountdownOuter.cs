﻿using System;

namespace td.features.waves
{
    [Serializable]
    public struct NextWaveCountdownOuter
    {
        public float countdown;
    }
}