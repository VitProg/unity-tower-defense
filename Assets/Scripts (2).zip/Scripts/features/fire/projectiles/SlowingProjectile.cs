﻿using System;

namespace td.features.fire.projectiles
{
    [Serializable]
    public struct SlowingProjectile
    {
        public float speedMultipler;
        public float duration;
    }
}