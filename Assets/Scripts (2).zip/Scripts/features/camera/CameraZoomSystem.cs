﻿using Cinemachine;
using Leopotam.EcsLite;
using Leopotam.EcsLite.Di;
using td.components.refs;
using td.utils;
using UnityEngine;

namespace td.features.camera
{
    public class CameraZoomSystem : IEcsRunSystem, IEcsInitSystem
    {
        private readonly EcsFilterInject<Inc<Ref<CinemachineVirtualCamera>>> entities = default;

        private float zoom = 0;
        
        public void Run(IEcsSystems systems)
        {
            var mouseZoom = 0;//Input.mouseScrollDelta.y;

            if (Input.GetKeyUp(KeyCode.Plus) || Input.GetKeyUp(KeyCode.KeypadPlus))
            {
                mouseZoom = -2;
            }

            if (Input.GetKeyUp(KeyCode.Minus) || Input.GetKeyUp(KeyCode.KeypadMinus))
            {
                mouseZoom = 2;
            }
            
            foreach (var entity in entities.Value)
            {
                var camera = entities.Pools.Inc1.Get(entity).reference;
                if (camera == null) continue;

                zoom += mouseZoom * Constants.Camera.ZoomIncreaseAmount;

                zoom = Mathf.Clamp(zoom, Constants.Camera.MaxZoom, Constants.Camera.MinZoom);

                camera.m_Lens.OrthographicSize = Mathf.Lerp(
                    camera.m_Lens.OrthographicSize,
                    zoom,
                    EasingUtils.EaseOutSine(Time.deltaTime * Constants.Camera.ZoomSpeed)
                );
            }
        }

        public void Init(IEcsSystems systems)
        {
            foreach (var entity in entities.Value)
            {
                var camera = entities.Pools.Inc1.Get(entity).reference;
                if (camera == null) continue;
                zoom = camera.m_Lens.OrthographicSize;
            }
        }
    }
}