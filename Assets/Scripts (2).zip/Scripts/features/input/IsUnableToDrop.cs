﻿namespace td.features.input
{
    public struct IsUnableToDrop
    {
        
    }
}