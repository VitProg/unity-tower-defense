﻿using System;
using Leopotam.EcsLite;

namespace td.features.enemies
{
    [Serializable]
    public struct EnemyDiedCommand
    {
        // public EcsPackedEntity EnemyEntity;
    }
}