﻿namespace td.common
{
    public class SharedData
    {
        public EnemyConfig[] EnemyConfigs;

        public EnemyConfig? GetEnemyConfig(string enemyName)
        {
            foreach (var enemyConfig in EnemyConfigs)
            {
                if (enemyConfig.name == enemyName)
                {
                    return enemyConfig;
                }
            }

            return null;
        }
    }
}