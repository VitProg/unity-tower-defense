﻿// using td.monoBehaviours;
// using UnityEngine;
//
// namespace td.common.cells.interfaces
// {
//     public interface ICell
//     {
//         public Int2 Coords { get; set; }
//         public CellData CellData { get; set; }
//     }
// }