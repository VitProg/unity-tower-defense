﻿// using Leopotam.EcsLite;
//
// namespace td.common.cells.interfaces
// {
//     public interface ICellCanBuild : ICell
//     {
//         public EcsPackedEntity? BuildingPackedEntity { get; set; }
//         public bool HasBuilding => BuildingPackedEntity != null;
//     }
// }