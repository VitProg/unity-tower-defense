﻿// using UnityEngine;
//
// namespace td.common.cells.interfaces
// {
//     public interface ICellSwitcherCanWalk : ICellCanWalk
//     {
//         public Int2 AlternativeNextCellCoordinates { get; set; }
//         public bool HasAlternativeNext { get; set; }
//         public int AlternativeDistanceToKernel  { get; set; }
//     }
// }