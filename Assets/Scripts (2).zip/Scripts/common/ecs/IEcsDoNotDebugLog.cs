﻿namespace td.common.ecs
{
    public interface IEcsDoNotDebugLog<T> where T : struct
    {
        
    }
}