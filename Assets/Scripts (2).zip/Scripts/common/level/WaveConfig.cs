﻿using System;

namespace td.common.level
{
    [Serializable]
    public struct WaveConfig
    {
        public WaveSpawnConfig[] spawns;
    }
}