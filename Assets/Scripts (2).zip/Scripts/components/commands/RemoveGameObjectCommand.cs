﻿using System;

namespace td.components.commands
{
    [Serializable]
    public struct RemoveGameObjectCommand
    {
    }
}