﻿using Cinemachine;
using Mitfart.LeoECSLite.UniLeo.Providers;

namespace td.components.refs
{
    public class RefCinemachineVirtualCameraProvider : EcsProvider<Ref<CinemachineVirtualCamera>>
    {
    }
}