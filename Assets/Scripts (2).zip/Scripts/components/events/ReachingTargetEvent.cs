﻿using System;
using Leopotam.EcsLite;
using td.common.ecs;

namespace td.components.events
{
    [Serializable]
    public struct ReachingTargetEvent : IEcsDoDebugLog<ReachingTargetEvent>
    {
        // public EcsPackedEntity TargetEntity;
    }
}