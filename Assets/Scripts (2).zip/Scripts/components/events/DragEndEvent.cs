﻿namespace td.components.events
{
    public struct DragEndEvent
    {
        
    }
}