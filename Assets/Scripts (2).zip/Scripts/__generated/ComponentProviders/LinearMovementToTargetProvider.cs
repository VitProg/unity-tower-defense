using td.common;

namespace td.components.behaviors
{
    public sealed class LinearMovementToTargetProvider : EcsProvider<LinearMovementToTarget>
    {
    }
}