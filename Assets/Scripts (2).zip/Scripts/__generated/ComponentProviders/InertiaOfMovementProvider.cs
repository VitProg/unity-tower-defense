using td.common;

namespace td.components.behaviors
{
    public sealed class InertiaOfMovementProvider : EcsProvider<InertiaOfMovement>
    {
    }
}