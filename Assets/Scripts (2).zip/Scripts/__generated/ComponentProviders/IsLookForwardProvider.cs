using td.common;

namespace td.components.flags
{
    public sealed class IsLookForwardProvider : EcsProvider<IsLookForward>
    {
    }
}