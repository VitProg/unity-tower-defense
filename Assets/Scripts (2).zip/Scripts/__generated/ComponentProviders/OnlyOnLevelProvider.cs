using td.common;

namespace td.components.flags
{
    public sealed class OnlyOnLevelProvider : EcsProvider<OnlyOnLevel>
    {
    }
}