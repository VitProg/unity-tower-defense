using td.common;

namespace td.features.camera
{
    public sealed class CursorFollowingProvider : EcsProvider<CursorFollowing>
    {
    }
}