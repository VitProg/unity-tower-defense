using td.common;

namespace td.features.towers
{
    public sealed class CannonTowerProvider : EcsProvider<CannonTower>
    {
    }
}