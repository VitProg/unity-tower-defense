using td.common;

namespace td.features.towers
{
    public sealed class TowerProvider : EcsProvider<Tower>
    {
    }
}