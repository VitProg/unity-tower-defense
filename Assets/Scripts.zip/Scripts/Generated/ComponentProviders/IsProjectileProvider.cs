using td.common;

namespace td.features.fire
{
    public sealed class IsProjectileProvider : EcsProvider<IsProjectile>
    {
    }
}