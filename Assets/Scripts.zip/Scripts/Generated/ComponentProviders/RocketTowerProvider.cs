using td.common;

namespace td.features.towers
{
    public sealed class RocketTowerProvider : EcsProvider<RocketTower>
    {
    }
}