using td.common;

namespace td.components.behaviors
{
    public sealed class MovementProvider : EcsProvider<Movement>
    {
    }
}