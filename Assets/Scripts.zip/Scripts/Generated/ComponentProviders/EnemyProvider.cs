using td.common;

namespace td.features.enemies
{
    public sealed class EnemyProvider : EcsProvider<Enemy>
    {
    }
}