﻿using System;
using System.Collections.Generic;

namespace td.utils
{
    public static class ArrayUtils
    {
        public static T[] Filter<T>(IEnumerable<T?> arr, Func<T?, bool> condition) where T : struct
        {
            var result = new List<T>();
            foreach (var item in arr)
            {
                if (item != null)
                {
                    result.Add((T)item);
                }
            }

            return result.ToArray();
        }

        public static T[] NotNullable<T>(IEnumerable<T?> arr) where T : struct =>
            Filter(arr, IsNotNull);

        private static bool IsNotNull<T>(T? value) where T : struct =>
            value != null;
    }
}