﻿namespace td.services
{
    public interface IPathService
    {
        void InitPath(LevelMap levelMap);
    }
}