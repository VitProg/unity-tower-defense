﻿// using System;
// using td.common.cells.interfaces;
// using UnityEngine;
//
// namespace td.common.cells.square
// {
//     [Serializable]
//     public class SquareCellSwitcherCanWalk : SquareCellCanWalk, ICellSwitcherCanWalk
//     {
//         public Int2 AlternativeNextCellCoordinates { get; set; }
//         public bool HasAlternativeNext { get; set; }
//         public int AlternativeDistanceToKernel { get; set; }
//     }
// }