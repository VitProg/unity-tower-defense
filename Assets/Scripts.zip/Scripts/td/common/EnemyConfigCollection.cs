﻿using System;

namespace td.common
{
    [Serializable]
    public struct EnemyConfigCollection
    {
        public EnemyConfig[] enemies;
    }
}