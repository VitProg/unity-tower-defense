﻿namespace td.common.ecs
{
    public interface IEcsDoDebugLog<T> where T : struct
    {
        
    }
}