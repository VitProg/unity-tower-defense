﻿using Leopotam.EcsLite;
using Leopotam.EcsLite.Di;
using td.components.events;

namespace td.systems.behaviors
{
    // public class RemoveEntityOnTargetSystem : IEcsRunSystem
    // {
        // private readonly EcsFilterInject<Inc<ReachingTargetEvent>>

        // public void Run(IEcsSystems systems)
        // {
            // throw new System.NotImplementedException();
        // }
    // }
}