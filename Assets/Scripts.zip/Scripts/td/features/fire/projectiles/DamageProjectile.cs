﻿using System;

namespace td.features.fire.projectiles
{
    [Serializable]
    public struct DamageProjectile
    {
        public float damage;
    }
}