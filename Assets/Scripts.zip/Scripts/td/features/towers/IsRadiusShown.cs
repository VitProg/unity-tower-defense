﻿using System;

namespace td.features.towers
{
    [Serializable]
    public struct IsRadiusShown
    {
        //todo add smooth opacity when show/hide
    }
}