﻿using System;

namespace td.features.impactsKernel
{
    [Serializable]
    public struct KernelHealOuterCommand
    {
        public float damage;
    }
}