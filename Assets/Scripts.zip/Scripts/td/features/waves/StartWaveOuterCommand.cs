﻿using System;

namespace td.features.waves
{
    [Serializable]
    public struct StartWaveOuterCommand
    {
        public int WaveNumber;
    }
}