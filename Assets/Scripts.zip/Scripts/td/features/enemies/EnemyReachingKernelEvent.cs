﻿using System;
using Leopotam.EcsLite;

namespace td.features.enemies
{
    [Serializable]
    public struct EnemyReachingKernelEvent
    {
        // public EcsPackedEntity EnemyEntity;
    }
}