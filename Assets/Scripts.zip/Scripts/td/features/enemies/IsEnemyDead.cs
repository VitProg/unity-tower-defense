﻿using System;

namespace td.features.enemies
{
    [Serializable]
    public struct IsEnemyDead
    {
        
    }
}