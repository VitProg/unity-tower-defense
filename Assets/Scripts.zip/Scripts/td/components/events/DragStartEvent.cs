﻿namespace td.components.events
{
    public struct DragStartEvent
    {
        
    }
}