﻿using Mitfart.LeoECSLite.UniLeo.Providers;
using UnityEngine;

namespace td.components.refs
{
    public class RefGameObjectProvider : EcsProvider<Ref<GameObject>>
    {
    }
}