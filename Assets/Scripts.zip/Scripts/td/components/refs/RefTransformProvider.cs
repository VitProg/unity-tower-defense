﻿using Mitfart.LeoECSLite.UniLeo.Providers;
using UnityEngine;

namespace td.components.refs
{
    public class RefTransformProvider : EcsProvider<Ref<Transform>>
    {
    }
}