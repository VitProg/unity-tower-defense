﻿using System;
using td.common;

namespace td.components.flags
{
    [Serializable]
    [GenerateProvider]
    public struct OnlyOnLevel
    {
        
    }
}