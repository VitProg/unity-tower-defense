﻿using System;
using Mitfart.LeoECSLite.UniLeo.Providers;
using td.common;

namespace td.components.flags
{
    [Serializable]
    [GenerateProvider]
    public struct IsLookForward
    {
      
    }
}