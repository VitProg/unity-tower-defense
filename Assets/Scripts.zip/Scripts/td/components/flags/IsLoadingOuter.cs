﻿using System;

namespace td.components.flags
{
    [Serializable]
    public struct IsLoadingOuter
    {
        
    }
}