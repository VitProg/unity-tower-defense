﻿namespace td.components.flags
{
    public struct IsDisabled
    {
        
    }
}